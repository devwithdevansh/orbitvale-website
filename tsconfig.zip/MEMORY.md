# MEMORY.md — Orbitvale Website

> Last updated: 2026-11-20

## Stack
- **Framework**: Next.js 14 App Router (TypeScript strict)
- **Styling**: Tailwind CSS 3 + CSS custom properties
- **Canvas**: Canvas 2D only — no WebGL / R3F in production
- **Fonts**: Self-hosted WOFF2 — Syne (`--font-display`) + JetBrains Mono (`--font-mono`)
- **Routing**: App Router; all pages under `src/app/`

## Design Tokens
| Token | Value |
|---|---|
| `bg` | `#08090b` |
| `accent` | `#7ff3d0` (mint) |
| `warm` | `#ffb86b` |
| `ink` | `#f4f4f6` |
| `muted` | `#8a8b93` |
| `dim` | `#5c5e66` |
| Ring tilt | `-13°` |

## Component Map

| Component | Location | Purpose |
|---|---|---|
| `Nav` | `components/Nav.tsx` | Fixed top nav with magnetic CTA, scroll-aware bg |
| `Footer` | `components/Footer.tsx` | Real PNG logo, newsletter hint, social links |
| `Preloader` | `components/Preloader.tsx` | Canvas 2D particle assembly into ORBITVALE letterforms |
| `CustomCursor` | `components/CustomCursor.tsx` | Spring-physics ring cursor (DAMPING=0.78, STIFFNESS=0.14) |
| `AmbientSound` | `components/AmbientSound.tsx` | Web Audio API drone — muted by default |
| `ScrollProgress` | `components/ScrollProgress.tsx` | OrbitRing in bottom-right corner as page progress |
| `ScrollClock` | `components/ScrollClock.tsx` | Master rAF scroll clock — single progress context |
| `SmoothScroll` | `components/SmoothScroll.tsx` | Lenis-based smooth scroll wrapper |
| `WarpTunnel` | `components/WarpTunnel.tsx` | Background particle canvas layer |
| `HeroSection` | `components/HeroSection.tsx` | Act I: Kepler orbital + TextReveal + MagneticButton CTAs |
| `OrbitalHeroSection` | `components/OrbitalHeroSection.tsx` | Canvas 2D Kepler simulation with pointer parallax |
| `SingularityCore` | `components/SingularityCore.tsx` | Act II: Particle brand object |
| `StatementSection` | `components/StatementSection.tsx` | Act II: SVG path draw reveal |
| `ServicesOrbit` | `components/ServicesOrbit.tsx` | Act III: Dual-ring ellipse orbit, depth occlusion |
| `WorksWheel` | `components/WorksWheel.tsx` | Act IV: Draggable 3D card carousel |
| `DeepTechSection` | `components/DeepTechSection.tsx` | Act V: Canvas 2D black hole simulation |
| `GlobeSection` | `components/GlobeSection.tsx` | Act VI: 3D dot-matrix globe with arc counters |
| `CtaSection` | `components/CtaSection.tsx` | Act VII: Star warp tunnel, hover-accelerates |
| `LogoMask` | `components/LogoMask.tsx` | Letter-stencil chapter reveal (Awwwards) |
| `TextReveal` | `components/TextReveal.tsx` | Word-by-word scroll reveal (Lusion-class) |
| `MagneticButton` | `components/MagneticButton.tsx` | Physical cursor attraction on hover |
| `MarqueeStrip` | `components/MarqueeStrip.tsx` | Infinite scrolling capability ticker |
| `LunarGravityCard` | `components/LunarGravityCard.tsx` | Mouse tilt physics card |
| `ContactFormCard` | `components/ContactFormCard.tsx` | LunarGravityCard contact form wrapper |
| `OrbitRing` | `components/brand/OrbitRing.tsx` | SVG ring with progress fill |
| `OrbitvaleLogo` | `components/brand/OrbitvaleLogo.tsx` | Real PNG logo + ring SVG variant |
| `OrbitvaleSvgLogo` | `components/brand/OrbitvaleSvgLogo.tsx` | Ring-only SVG (animation only) |

## Pages

| Route | File | Notes |
|---|---|---|
| `/` | `app/page.tsx` → `HomeClient.tsx` | Full 7-act immersive home |
| `/work` | `app/work/page.tsx` | Editorial numbered project list |
| `/work/[slug]` | `app/work/[slug]/page.tsx` | 6 SSG case study pages |
| `/services` | `app/services/page.tsx` | ServicesOrbit + detail grid |
| `/about` | `app/about/page.tsx` | Timeline + principles |
| `/contact` | `app/contact/page.tsx` | ContactFormCard + LunarGravity |
| `/_not-found` | `app/not-found.tsx` | Animated SVG ocean 404 |
| `/sitemap.xml` | `app/sitemap.ts` | Full sitemap |
| `/robots.txt` | `app/robots.ts` | robots.txt |

## Assets

| Asset | Path | Notes |
|---|---|---|
| Logo PNG | `public/brand/orbitvale.png` | 1.1 MB, white-on-black, `mix-blend-screen` |
| Project covers | `public/covers/*.svg` + `.jpg` | 6 dark-tech gradient SVGs |
| Syne WOFF2 | `public/fonts/Syne-*.woff2` | Self-hosted, variable weight |
| JetBrains Mono WOFF2 | `public/fonts/JetBrainsMono-*.woff2` | Self-hosted, variable weight |

## Rules

1. `npx tsc --noEmit` → 0 errors after every edit batch
2. `npm run build` → must pass (always run with `BypassSandbox: true`)
3. Never export non-Next.js symbols from `app/` page files (causes build type error)
4. No R3F / WebGL — Canvas 2D only
5. All canvases: DPR cap ≤ 2, IntersectionObserver pause when off-screen
6. `prefers-reduced-motion` respected in all animated components
7. Real logo PNG always used for wordmark — never hand-coded SVG paths
8. PowerShell: use `;` not `&&` to chain commands
9. `font-mono` for labels/counters/nav · `font-display` for headings
10. Motion: "one loud moment per viewport — never two shaders fighting"
11. No swarm — user requested sequential execution only

## Build Notes

- **EPERM on Windows sandbox**: `npm run build` fails with EPERM on `.next/server/app/*` in sandboxed mode. Always use `BypassSandbox: true`.
- **Smart quotes break TS**: Always use straight quotes in source files.
- **metadataBase**: Set to `https://orbitvale.com` in layout.tsx to suppress OG warnings.

## Completed Phases

- [x] Self-hosted fonts (Syne + JetBrains Mono WOFF2)
- [x] Master scroll clock (ScrollClock context)
- [x] Real logo PNG in Nav, Footer, Preloader
- [x] Particle preloader (Canvas 2D letter assembly)
- [x] 6 case study pages with metrics + editorial layout
- [x] ServicesOrbit with depth occlusion
- [x] Black hole DeepTechSection (Canvas 2D)
- [x] Globe with great-circle arcs + animated counters
- [x] Star warp CTA with hover-accelerate
- [x] Custom cursor (spring physics)
- [x] LunarGravityCard (mouse tilt physics)
- [x] AmbientSound (Web Audio API drone)
- [x] 404 animated ocean page
- [x] Sitemap + robots.txt
- [x] LogoMask chapter reveal (Awwwards)
- [x] TextReveal word-by-word stagger (Lusion-class)
- [x] MagneticButton cursor attraction
- [x] MarqueeStrip capability ticker
- [x] View Transitions API (native page morphs)
- [x] metadataBase + Twitter card metadata
- [x] Work page — editorial numbered list
